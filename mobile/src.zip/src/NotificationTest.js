
import React from 'react';
import { View, Button, Alert } from 'react-native';
import { scheduleReminder } from './utlis/notifications';

export default function NotificationTest() {
  const testNotification = async () => {
    try {
      const allowed = await scheduleReminder({
        title: 'Saathi Medicine Reminder',
        body: 'It is time to take your medicine.',
        hour: new Date().getHours(),
        minute: (new Date().getMinutes() + 2) % 60,
        days: [
          'Monday', 'Tuesday', 'Wednesday',
          'Thursday', 'Friday', 'Saturday', 'Sunday',
        ],
      });

      Alert.alert('Reminder scheduled', 'Check your phone in a few minutes.');
    } catch (error) {
      Alert.alert('Notification error', error.message);
    }
  };

  return (
    <View style={{ padding: 20, marginTop: 50 }}>
      <Button
        title="Test Notification"
        onPress={testNotification}
      />
    </View>
  );
}
