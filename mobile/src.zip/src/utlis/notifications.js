
import * as Notifications from 'expo-notifications';
import { Platform } from 'react-native';

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowBanner: true,
    shouldShowList: true,
    shouldPlaySound: true,
    shouldSetBadge: false,
  }),
});

export async function requestNotificationPermission() {
  if (Platform.OS === 'android') {
    await Notifications.setNotificationChannelAsync('reminders', {
      name: 'Medicine and Routine Reminders',
      importance: Notifications.AndroidImportance.MAX,
      sound: 'default',
    });
  }

  const { status } = await Notifications.requestPermissionsAsync();
  return status === 'granted';
}

export async function scheduleReminder({
  title,
  body,
  hour,
  minute,
  days,
}) {
  const allowed = await requestNotificationPermission();

  if (!allowed) {
    throw new Error('Notification permission was not granted.');
  }

  const weekdayMap = {
    Sunday: 1,
    Monday: 2,
    Tuesday: 3,
    Wednesday: 4,
    Thursday: 5,
    Friday: 6,
    Saturday: 7,
  };

  const ids = [];

  for (const day of days) {
    const id = await Notifications.scheduleNotificationAsync({
  content: {
  title,
  body,
  data: { type: 'saathi-reminder' },
},
      trigger: {
        type: Notifications.SchedulableTriggerInputTypes.WEEKLY,
        weekday: weekdayMap[day],
        hour,
        minute,
        channelId: 'reminders',
      },
    });

    ids.push(id);
  }

  return ids;
}

export async function cancelReminder(id) {
  await Notifications.cancelScheduledNotificationAsync(id);
}

export async function cancelAllReminders() {
  await Notifications.cancelAllScheduledNotificationsAsync();
}
