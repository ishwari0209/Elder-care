import React, { useEffect, useState } from 'react';
import { makeRedirectUri } from 'expo-auth-session';

import { View, Text, TouchableOpacity, ActivityIndicator } from 'react-native';
import * as WebBrowser from 'expo-web-browser';
import * as Google from 'expo-auth-session/providers/google';
import { Ionicons } from '@expo/vector-icons';
import { C } from '../theme';
import { useSaathi } from '../context/SaathiContext';
import { googleAuth } from '../api';
import { GOOGLE } from '../googleConfig';

WebBrowser.maybeCompleteAuthSession();

// Shown under the normal Sign Up / Log In buttons.
// onSuccess(user) is called after the backend accepts the Google token.
export default function GoogleButton({ label = 'Continue with Google', onSuccess, onError, disabled }) {
  const { t } = useSaathi();
  const [busy, setBusy] = useState(false);
 const redirectUri = makeRedirectUri({
  scheme: 'saathi',
  path: 'oauthredirect',
});

console.log('Google redirect URI:', redirectUri);
 const [request, response, promptAsync] =
  Google.useIdTokenAuthRequest({
    clientId: GOOGLE.webClientId,
    webClientId: GOOGLE.webClientId,
    androidClientId: GOOGLE.androidClientId,
    iosClientId: GOOGLE.iosClientId || undefined,
    redirectUri: makeRedirectUri({
      scheme: 'saathi',
    }),
  });

 useEffect(() => {
  if (!response) return;

  if (response.type === "success") {
    console.log('Google response:', response);
console.log('Google ID token:', response.params?.id_token);
    const idToken =
      response.params?.id_token ||
      response.authentication?.idToken;

    if (!idToken) {
      onError?.(
        "Google sign-in returned no ID token. Check the OAuth client configuration."
      );
      return;
    }

    (async () => {
      try {
        setBusy(true);
        const user = await googleAuth(idToken);
        onSuccess?.(user);
      } catch (e) {
        console.error("Google backend authentication failed:", e);
        onError?.(e.message || t("Google sign-in failed. Please try again."));
      } finally {
        setBusy(false);
      }
    })();
  } else if (response.type === "error") {
    console.error("Google OAuth error:", response.error);
    onError?.(
      response.error?.message ||
      response.params?.error_description ||
      t("Google sign-in failed. Please try again.")
    );
  } else if (response.type === "cancel") {
    // User cancelled the sign-in flow.
  }
}, [response]);

  const off = disabled || busy || !request;
  return (
    <View style={{ marginTop: 6 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', marginVertical: 10 }}>
        <View style={{ flex: 1, height: 1, backgroundColor: C.line }} />
        <Text style={{ marginHorizontal: 12, color: C.grey, fontWeight: '700' }}>{t('or')}</Text>
        <View style={{ flex: 1, height: 1, backgroundColor: C.line }} />
      </View>
      <TouchableOpacity
        accessibilityRole="button"
        onPress={() => promptAsync()}
        disabled={off}
        activeOpacity={0.8}
        style={{
          minHeight: 56, borderRadius: 16, flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
          backgroundColor: '#fff', borderWidth: 1.5, borderColor: C.line, paddingHorizontal: 20, opacity: off ? 0.6 : 1,
          shadowColor: '#0F2E5C', shadowOpacity: 0.1, shadowRadius: 8, shadowOffset: { width: 0, height: 3 }, elevation: 3,
        }}
      >
        {busy ? <ActivityIndicator color={C.teal} /> : <Ionicons name="logo-google" size={22} color="#DB4437" />}
        <Text style={{ fontSize: 18, fontWeight: '700', color: C.text, marginLeft: 12 }}>{t(label)}</Text>
      </TouchableOpacity>
    </View>
  );
}
