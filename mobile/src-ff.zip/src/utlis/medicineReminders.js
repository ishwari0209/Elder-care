
import { Platform } from 'react-native';
import * as Notifications from 'expo-notifications';

const FLAG = 'saathiMedicineReminder';
const CHANNEL_ID = 'medicine-reminders';

const WEEKDAY = {
  Sun: 1,
  Mon: 2,
  Tue: 3,
  Wed: 4,
  Thu: 5,
  Fri: 6,
  Sat: 7,
};

const ALL_DAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

function parseTime(value) {
  const match = String(value || '')
    .trim()
    .match(/^(\d{1,2})[:.](\d{2})\s*(AM|PM)?$/i);

  if (!match) return null;

  let hour = Number(match[1]);
  const minute = Number(match[2]);
  const period = match[3]?.toUpperCase();

  if (minute > 59) return null;

  if (period) {
    if (hour < 1 || hour > 12) return null;
    hour = (hour % 12) + (period === 'PM' ? 12 : 0);
  } else if (hour > 23) {
    return null;
  }

  return { hour, minute };
}

function splitTimes(value) {
  // Supports one time or comma/semicolon-separated times.
  return String(value || '')
    .split(/[,;\n]+/)
    .map(value => value.trim())
    .filter(Boolean);
}

function localDateString(date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}
export async function testMedicineNotification() {
  const permission = await Notifications.requestPermissionsAsync();

  console.log('Notification permission:', permission);

  const id = await Notifications.scheduleNotificationAsync({
    content: {
      title: 'Saathi Test',
      body: 'Medicine notifications are working!',
      data: { test: true },
    },
    trigger: {
      type: Notifications.SchedulableTriggerInputTypes.TIME_INTERVAL,
      seconds: 10,
    },
  });

  console.log('Test notification scheduled:', id);
}
async function cancelExistingMedicineReminders() {
  const scheduled = await Notifications.getAllScheduledNotificationsAsync();

  for (const item of scheduled) {
    if (item.content?.data?.[FLAG]) {
      await Notifications.cancelScheduledNotificationAsync(item.identifier);
    }
  }
}

export async function syncMedicineReminders(medicines = []) {
  if (Platform.OS === 'web') return;

  const permission = await Notifications.getPermissionsAsync();
  if (!permission.granted) {
    const requested = await Notifications.requestPermissionsAsync();
    if (!requested.granted) return;
  }

  if (Platform.OS === 'android') {
  await Notifications.setNotificationChannelAsync(CHANNEL_ID, {
    name: 'Medicine reminders',
    importance: Notifications.AndroidImportance.MAX,
  });
}

  await cancelExistingMedicineReminders();

  const today = localDateString(new Date());

  for (const medicine of medicines) {
    if (!medicine.name || !medicine.times) continue;
    if (medicine.end && medicine.end < today) continue;
    if (medicine.start && medicine.start > today) continue;

    const days = Array.isArray(medicine.days) && medicine.days.length
      ? medicine.days
      : ALL_DAYS;

    for (const timeText of splitTimes(medicine.times)) {
      const time = parseTime(timeText);
      if (!time) {
        console.warn('Invalid medicine reminder time:', timeText);
        continue;
      }

      for (const day of days) {
        const weekday = WEEKDAY[day];
        if (!weekday) continue;

        try {
          await Notifications.scheduleNotificationAsync({
           content: {
  title: 'Saathi Medicine Reminder',
  body: `Time to take ${medicine.name} (${medicine.dosage}).`,
  data: {
    [FLAG]: true,
    medicineId: String(medicine._id || ''),
    time: timeText,
  },
},
            trigger: {
              type: Notifications.SchedulableTriggerInputTypes.WEEKLY,
              weekday,
              hour: time.hour,
              minute: time.minute,
              ...(Platform.OS === 'android'
                ? { channelId: CHANNEL_ID }
                : {}),
            },
          });
        } catch (error) {
          console.warn('Could not schedule medicine reminder:', error);
        }
      }
    }
  }

  const scheduled = await Notifications.getAllScheduledNotificationsAsync();
  console.log(
    'Saathi medicine reminders scheduled:',
    scheduled.filter(item => item.content?.data?.[FLAG]).length
  );
}
